package com.spb;

import java.util.Scanner;

import exp7.Arithmetic;
import exp7.Stat;
import exp7.Trig;

public class PackDemo {
 public static void main(String[] args) {

     Scanner sc = new Scanner(System.in);

     // -------- Trigonometric demo --------
     System.out.print("Enter angle in degrees: ");
     double angle = sc.nextDouble();

     Trig t = new Trig(angle);
     System.out.println("\nTrigonometric operations for angle: " + angle + " degrees");
     System.out.println("Sine      : " + t.getSine());
     System.out.println("Cosine    : " + t.getCosine());
     System.out.println("Tangent   : " + t.getTangent());
     System.out.println("Secant    : " + t.getSecant());
     System.out.println("Cosecant  : " + t.getCosecant());
     System.out.println("Cotangent : " + t.getCotangent());

     // -------- Arithmetic demo --------
     Arithmetic a = new Arithmetic();
     System.out.print("\nEnter two float numbers (a b): ");
     float x = sc.nextFloat();
     float y = sc.nextFloat();

     System.out.println("\nArithmetic operations:");
     System.out.println("a + b = " + a.add(x, y));
     System.out.println("a - b = " + a.subtract(x, y));
     System.out.println("a * b = " + a.multiply(x, y));
     System.out.println("a / b = " + a.divide(x, y));

     // -------- Statistical demo --------
     System.out.print("\nEnter number of elements for statistics: ");
     int n = sc.nextInt();
     float[] data = new float[n];

     System.out.println("Enter " + n + " float values:");
     for (int i = 0; i < n; i++) {
         data[i] = sc.nextFloat();
     }

     Stat s = new Stat();
     System.out.println("\nStatistical operations:");
     System.out.println("Min   : " + s.min(data));
     System.out.println("Max   : " + s.max(data));
     System.out.println("Count : " + s.count(data));
     System.out.println("Sum   : " + s.sum(data));
     System.out.println("Avg   : " + s.average(data));

     sc.close();
 }
}

