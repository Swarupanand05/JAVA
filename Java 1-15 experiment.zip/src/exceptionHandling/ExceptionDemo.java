package exceptionHandling;

//ExceptionDemo.java
import java.util.Scanner;

public class ExceptionDemo {
 public static void main(String[] args) {

     Scanner sc = new Scanner(System.in);

     System.out.print("Enter two integers (a b): ");
     int a = sc.nextInt();
     int b = sc.nextInt();

     MathOperation mo = new MathOperation(a, b);

     try {
         System.out.println("Addition Result      : " + mo.add());
     } catch (TooLongAdditionException e) {
         System.out.println("Exception: " + e.getMessage());
     }

     try {
         System.out.println("Subtraction Result   : " + mo.subtract());
     } catch (NegativeAnswerException e) {
         System.out.println("Exception: " + e.getMessage());
     }

     try {
         System.out.println("Multiplication Result: " + mo.multiply());
     } catch (TooLongMultiplicationException e) {
         System.out.println("Exception: " + e.getMessage());
     }

     System.out.println("Division Result      : " + mo.divide());

     sc.close();
 }
}

