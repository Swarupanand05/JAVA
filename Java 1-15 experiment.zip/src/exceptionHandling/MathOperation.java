package exceptionHandling;

//MathOperation.java
public class MathOperation {

 private int a;
 private int b;

 public MathOperation(int a, int b) {
     this.a = a;
     this.b = b;
 }

 // Addition
 public int add() throws TooLongAdditionException {
     int result = a + b;
     if (result > 1000) {
         throw new TooLongAdditionException("Addition result " + result + " exceeds 1000!");
     }
     return result;
 }

 // Subtraction
 public int subtract() throws NegativeAnswerException {
     int result = a - b;
     if (result < 0) {
         throw new NegativeAnswerException("Subtraction result " + result + " is negative!");
     }
     return result;
 }

 // Multiplication
 public int multiply() throws TooLongMultiplicationException {
     int result = a * b;
     if (result > 5000) {
         throw new TooLongMultiplicationException("Multiplication result " + result + " exceeds 5000!");
     }
     return result;
 }

 // Division (normal division - exception if b=0)
 public int divide() {
     if (b == 0) {
         System.out.println("Cannot divide by zero!");
         return 0;
     }
     return a / b;
 }
}

