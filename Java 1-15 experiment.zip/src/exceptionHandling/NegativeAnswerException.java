package exceptionHandling;

//NegativeAnswerException.java
public class NegativeAnswerException extends Exception {
 public NegativeAnswerException(String message) {
     super(message);
 }
}
