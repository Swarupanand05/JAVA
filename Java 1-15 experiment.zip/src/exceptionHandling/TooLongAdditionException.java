package exceptionHandling;

//TooLongAdditionException.java
public class TooLongAdditionException extends Exception {
 public TooLongAdditionException(String message) {
     super(message);
 }
}
