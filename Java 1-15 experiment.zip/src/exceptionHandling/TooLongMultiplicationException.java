package exceptionHandling;

//TooLongMultiplicationException.java
public class TooLongMultiplicationException extends Exception {
 public TooLongMultiplicationException(String message) {
     super(message);
 }
}

