package exp10;

//StudentInfo.java
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class StudentInfo {

 @SuppressWarnings("deprecation")
public static void main(String[] args) {

     DataInputStream dis = new DataInputStream(System.in);

     try {
         // Step 2: Read input from user using DataInputStream
         System.out.print("Enter Roll No: ");
         String roll = dis.readLine();

         System.out.print("Enter Class: ");
         String cls = dis.readLine();

         System.out.print("Enter Age: ");
         String age = dis.readLine();

         System.out.print("Enter Weight: ");
         String weight = dis.readLine();

         System.out.print("Enter Height: ");
         String height = dis.readLine();

         System.out.print("Enter City: ");
         String city = dis.readLine();

         System.out.print("Enter Phone: ");
         String phone = dis.readLine();

         // Prepare the record (text format)
         String record = "Roll No: " + roll + "\n" +
                         "Class: " + cls + "\n" +
                         "Age: " + age + "\n" +
                         "Weight: " + weight + "\n" +
                         "Height: " + height + "\n" +
                         "City: " + city + "\n" +
                         "Phone: " + phone + "\n\n";

         // Step 3: Write data to file using FileOutputStream
         FileOutputStream fout = new FileOutputStream("studentdata.txt", true); // append mode
         byte[] b = record.getBytes();
         fout.write(b);
         fout.close();

         System.out.println("\nStudent data saved to file successfully.");

         // Step 4: Read data back using FileInputStream
         System.out.println("\n----- Reading from file studentdata.txt -----");
         FileInputStream fin = new FileInputStream("studentdata.txt");

         int ch;
         while ((ch = fin.read()) != -1) {
             System.out.print((char) ch);
         }

         fin.close();

     } catch (IOException e) {
         System.out.println("Error: " + e);
     }

 }
}

