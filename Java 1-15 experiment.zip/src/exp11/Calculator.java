package exp11;

//Calculator.java
import javax.swing.*;
import java.awt.event.*;

public class Calculator implements ActionListener {

 JFrame frame;
 JTextField textField;
 JButton[] numberButtons = new JButton[10];
 JButton addButton, subButton, mulButton, divButton;
 JButton decButton, equButton, clrButton;
 JPanel panel;

 double num1 = 0, num2 = 0, result = 0;
 char operator;

 Calculator() {
     // 1) Create frame
     frame = new JFrame("Standard Calculator");
     frame.setSize(400, 550);
     frame.setLayout(null);
     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

     // 3) Create text field
     textField = new JTextField();
     textField.setBounds(50, 25, 300, 50);  // 4) setBounds
     textField.setEditable(false);

     // 3) Create buttons
     addButton = new JButton("+");
     subButton = new JButton("-");
     mulButton = new JButton("*");
     divButton = new JButton("/");
     decButton = new JButton(".");
     equButton = new JButton("=");
     clrButton = new JButton("C");

     JButton[] funcButtons = {addButton, subButton, mulButton, divButton,
                              decButton, equButton, clrButton};

     for (int i = 0; i < funcButtons.length; i++) {
         funcButtons[i].addActionListener(this);  // 1) implements ActionListener
         funcButtons[i].setFocusable(false);
     }

     for (int i = 0; i < 10; i++) {
         numberButtons[i] = new JButton(String.valueOf(i));
         numberButtons[i].addActionListener(this);
         numberButtons[i].setFocusable(false);
     }

     // Panel with grid for buttons
     panel = new JPanel();
     panel.setBounds(50, 100, 300, 300);
     panel.setLayout(new java.awt.GridLayout(4, 4, 10, 10));

     // Add buttons to panel in calculator layout
     // Row 1: 7 8 9 /
     panel.add(numberButtons[7]);
     panel.add(numberButtons[8]);
     panel.add(numberButtons[9]);
     panel.add(divButton);

     // Row 2: 4 5 6 *
     panel.add(numberButtons[4]);
     panel.add(numberButtons[5]);
     panel.add(numberButtons[6]);
     panel.add(mulButton);

     // Row 3: 1 2 3 -
     panel.add(numberButtons[1]);
     panel.add(numberButtons[2]);
     panel.add(numberButtons[3]);
     panel.add(subButton);

     // Row 4: 0 . = +
     panel.add(numberButtons[0]);
     panel.add(decButton);
     panel.add(equButton);
     panel.add(addButton);

     // Clear button below
     clrButton.setBounds(50, 420, 300, 40);

     // 5) Add components to frame
     frame.add(textField);
     frame.add(panel);
     frame.add(clrButton);

     frame.setVisible(true);
 }

 // 6) & 7) Handle button events
 @Override
 public void actionPerformed(ActionEvent e) {

     // Number buttons
     for (int i = 0; i < 10; i++) {
         if (e.getSource() == numberButtons[i]) {
             textField.setText(textField.getText() + i);
             return;
         }
     }

     // Decimal point
     if (e.getSource() == decButton) {
         if (!textField.getText().contains(".")) {
             textField.setText(textField.getText() + ".");
         }
         return;
     }

     // Operators
     if (e.getSource() == addButton) {
         setOperator('+');
     } else if (e.getSource() == subButton) {
         setOperator('-');
     } else if (e.getSource() == mulButton) {
         setOperator('*');
     } else if (e.getSource() == divButton) {
         setOperator('/');
     }

     // Equals button: perform appropriate function
     if (e.getSource() == equButton) {
         try {
             num2 = Double.parseDouble(textField.getText());
             switch (operator) {
                 case '+':
                     result = num1 + num2;
                     break;
                 case '-':
                     result = num1 - num2;
                     break;
                 case '*':
                     result = num1 * num2;
                     break;
                 case '/':
                     if (num2 == 0) {
                         textField.setText("Error: /0");
                         return;
                     }
                     result = num1 / num2;
                     break;
             }
             textField.setText(String.valueOf(result));
         } catch (NumberFormatException ex) {
             textField.setText("Error");
         }
     }

     // Clear button
     if (e.getSource() == clrButton) {
         textField.setText("");
         num1 = num2 = result = 0;
         operator = '\0';
     }
 }

 private void setOperator(char op) {
     try {
         num1 = Double.parseDouble(textField.getText());
         operator = op;
         textField.setText("");
     } catch (NumberFormatException ex) {
         textField.setText("Error");
     }
 }

 public static void main(String[] args) {
     new Calculator();
 }
}
