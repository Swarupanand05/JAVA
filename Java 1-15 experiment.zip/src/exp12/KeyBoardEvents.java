package exp12;

//KeyBoardEvents.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class KeyBoardEvents extends JFrame implements KeyListener {

 private JTextArea textArea;

 public KeyBoardEvents() {
     super("Key Event Demo");

     // 2) Create contentPane & TextArea
     Container c = getContentPane();
     c.setLayout(new BorderLayout());

     textArea = new JTextArea();
     textArea.setFont(new Font("Arial", Font.PLAIN, 16));
     textArea.setEditable(true);
     textArea.setText("Type here and watch key events...\n");

     // 3) Add text area to content pane and add KeyListener
     JScrollPane scrollPane = new JScrollPane(textArea);
     c.add(scrollPane, BorderLayout.CENTER);

     textArea.addKeyListener(this);

     // 5) Frame properties
     setSize(500, 300);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     setLocationRelativeTo(null); // center
     setVisible(true);
 }

 // 4) Implement keyPressed, keyReleased, keyTyped

 @Override
 public void keyPressed(KeyEvent e) {
     textArea.append("\nKey Pressed: " 
             + KeyEvent.getKeyText(e.getKeyCode()) 
             + " (Code: " + e.getKeyCode() + ")");
 }

 @Override
 public void keyReleased(KeyEvent e) {
     textArea.append("\nKey Released: " 
             + KeyEvent.getKeyText(e.getKeyCode()));
 }

 @Override
 public void keyTyped(KeyEvent e) {
     textArea.append("\nKey Typed: '" + e.getKeyChar() + "'");
 }

 public static void main(String[] args) {
     new KeyBoardEvents();
 }
}
