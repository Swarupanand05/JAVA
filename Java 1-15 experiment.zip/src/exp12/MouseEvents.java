package exp12;

//MouseEvents.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MouseEvents extends JFrame implements MouseListener, MouseMotionListener {

 private JTextArea textArea;

 public MouseEvents() {
     super("Mouse Event Demo");

     // 2) Create contentPane & TextArea
     Container c = getContentPane();
     c.setLayout(new BorderLayout());

     textArea = new JTextArea();
     textArea.setFont(new Font("Arial", Font.PLAIN, 16));
     textArea.setEditable(false);
     textArea.setText("Move / Click mouse in this area...\n");

     JScrollPane scrollPane = new JScrollPane(textArea);
     c.add(scrollPane, BorderLayout.CENTER);

     // 3) Add mouse listener and mouse motion listener to textArea
     textArea.addMouseListener(this);
     textArea.addMouseMotionListener(this);

     // 5) Frame properties
     setSize(500, 300);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     setLocationRelativeTo(null); // center
     setVisible(true);
 }

 // Helper to show messages
 private void display(String msg, MouseEvent e) {
     textArea.append("\n" + msg + " at (" + e.getX() + ", " + e.getY() + ")");
 }

 // 4) Implement MouseListener methods

 @Override
 public void mouseClicked(MouseEvent e) {
     display("Mouse Clicked (Clicks: " + e.getClickCount() + ")", e);
 }

 @Override
 public void mousePressed(MouseEvent e) {
     display("Mouse Pressed", e);
 }

 @Override
 public void mouseReleased(MouseEvent e) {
     display("Mouse Released", e);
 }

 @Override
 public void mouseEntered(MouseEvent e) {
     textArea.append("\nMouse Entered the text area");
 }

 @Override
 public void mouseExited(MouseEvent e) {
     textArea.append("\nMouse Exited the text area");
 }

 // 4) Implement MouseMotionListener methods

 @Override
 public void mouseDragged(MouseEvent e) {
     display("Mouse Dragged", e);
 }

 @Override
 public void mouseMoved(MouseEvent e) {
     display("Mouse Moved", e);
 }

 public static void main(String[] args) {
     new MouseEvents();
 }
}
