package exp13;

//MyNotepad.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class MyNotepad extends JFrame implements ActionListener {

 JTextArea textArea;
 JFileChooser fileChooser;
 String currentFile = null;

 // Menu items
 JMenuItem newItem, openItem, saveItem, exitItem;
 JMenuItem cutItem, copyItem, pasteItem;
 JMenuItem fontItem;

 public MyNotepad() {

     // 1) Create Frame
     setTitle("My Notepad");
     setSize(700, 500);
     setLocationRelativeTo(null);
     setDefaultCloseOperation(EXIT_ON_CLOSE);

     // Text Area
     textArea = new JTextArea();
     JScrollPane scrollPane = new JScrollPane(textArea);

     // 2) Create Menu Bar
     JMenuBar menuBar = new JMenuBar();

     // 3) Create Menus
     JMenu fileMenu = new JMenu("File");
     JMenu editMenu = new JMenu("Edit");
     JMenu formatMenu = new JMenu("Format");

     // File Menu Items
     newItem = new JMenuItem("New");
     openItem = new JMenuItem("Open");
     saveItem = new JMenuItem("Save");
     exitItem = new JMenuItem("Exit");

     // Add to File Menu
     fileMenu.add(newItem);
     fileMenu.add(openItem);
     fileMenu.add(saveItem);
     fileMenu.addSeparator();
     fileMenu.add(exitItem);

     // Edit Menu Items
     cutItem = new JMenuItem("Cut");
     copyItem = new JMenuItem("Copy");
     pasteItem = new JMenuItem("Paste");

     editMenu.add(cutItem);
     editMenu.add(copyItem);
     editMenu.add(pasteItem);

     // Format Menu Items
     fontItem = new JMenuItem("Font");
     formatMenu.add(fontItem);

     // Add Menus to MenuBar
     menuBar.add(fileMenu);
     menuBar.add(editMenu);
     menuBar.add(formatMenu);

     setJMenuBar(menuBar);

     // 4) Use dialog controls
     fileChooser = new JFileChooser();

     // Add Listeners
     newItem.addActionListener(this);
     openItem.addActionListener(this);
     saveItem.addActionListener(this);
     exitItem.addActionListener(this);

     cutItem.addActionListener(this);
     copyItem.addActionListener(this);
     pasteItem.addActionListener(this);

     fontItem.addActionListener(this);

     // Add Text Area
     add(scrollPane);

     setVisible(true);
 }

 // 5) Handle Events
 @Override
 public void actionPerformed(ActionEvent e) {

     // New
     if (e.getSource() == newItem) {
         textArea.setText("");
         currentFile = null;
     }

     // Open Dialog
     if (e.getSource() == openItem) {
         int response = fileChooser.showOpenDialog(this);
         if (response == JFileChooser.APPROVE_OPTION) {
             File file = fileChooser.getSelectedFile();
             readFile(file);
         }
     }

     // Save Dialog
     if (e.getSource() == saveItem) {
         if (currentFile == null) {
             int response = fileChooser.showSaveDialog(this);
             if (response == JFileChooser.APPROVE_OPTION) {
                 File file = fileChooser.getSelectedFile();
                 writeFile(file);
             }
         } else {
             writeFile(new File(currentFile));
         }
     }

     // Exit
     if (e.getSource() == exitItem) {
         System.exit(0);
     }

     // Edit: Cut Copy Paste
     if (e.getSource() == cutItem) textArea.cut();
     if (e.getSource() == copyItem) textArea.copy();
     if (e.getSource() == pasteItem) textArea.paste();

     // Format → Font dialog
     if (e.getSource() == fontItem) showFontDialog();
 }

 // ---- FILE OPERATIONS ----
 private void readFile(File file) {
     try {
         BufferedReader br = new BufferedReader(new FileReader(file));
         textArea.read(br, null);
         br.close();
         currentFile = file.getAbsolutePath();
     } catch (Exception ex) {
         JOptionPane.showMessageDialog(this, "Error reading file!");
     }
 }

 private void writeFile(File file) {
     try {
         BufferedWriter bw = new BufferedWriter(new FileWriter(file));
         textArea.write(bw);
         bw.close();
         currentFile = file.getAbsolutePath();
     } catch (Exception ex) {
         JOptionPane.showMessageDialog(this, "Error saving file!");
     }
 }

 // ---- SIMPLE FONT DIALOG ----
 private void showFontDialog() {
     String[] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment()
             .getAvailableFontFamilyNames();

     String font = (String) JOptionPane.showInputDialog(
             this,
             "Choose Font:",
             "Font Dialog",
             JOptionPane.PLAIN_MESSAGE,
             null,
             fonts,
             textArea.getFont().getFamily()
     );

     if (font != null) {
         textArea.setFont(new Font(font, Font.PLAIN, 18));
     }
 }

 public static void main(String[] args) {
     new MyNotepad();
 }
}
