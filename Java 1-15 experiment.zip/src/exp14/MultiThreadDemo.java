package exp14;

//MultiThreadDemo.java
import java.util.Random;

//1) RandomNumberThread (Generates number every 1 sec)
class RandomNumberThread extends Thread {
 public void run() {
     Random rand = new Random();

     while (true) {
         int num = rand.nextInt(100) + 1; // random number 1–100
         System.out.println("\nGenerated Number: " + num);

         if (num % 2 == 0) {
             // Even — Square thread
             SquareThread st = new SquareThread(num);
             st.start();
         } else {
             // Odd — Cube thread
             CubeThread ct = new CubeThread(num);
             ct.start();
         }

         try {
             Thread.sleep(1000); // 8) Generate every 1 second
         } catch (InterruptedException e) {
             System.out.println(e);
         }
     }
 }
}

//3) SquareThread
class SquareThread extends Thread {
 int number;

 SquareThread(int number) {
     this.number = number;
 }

 // 4) compute square
 public void run() {
     int square = number * number;
     System.out.println("Square of " + number + " = " + square);
 }
}

//5) CubeThread
class CubeThread extends Thread {
 int number;

 CubeThread(int number) {
     this.number = number;
 }

 // 6) compute cube
 public void run() {
     int cube = number * number * number;
     System.out.println("Cube of " + number + " = " + cube);
 }
}

//MAIN CLASS
public class MultiThreadDemo {
 public static void main(String[] args) {
     // 7) Start the random number generator thread
     RandomNumberThread rnt = new RandomNumberThread();
     rnt.start();
 }
}

