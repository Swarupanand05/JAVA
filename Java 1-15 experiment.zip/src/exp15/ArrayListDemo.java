package exp15;

//ArrayListDemo.java
import java.util.ArrayList;
import java.util.Iterator;

//Simple Book class
class Book {
 private int bookId;
 private String bookName;
 private String author;
 private String publisher;
 private int quantity;

 public Book(int bookId, String bookName, String author, String publisher, int quantity) {
     this.bookId = bookId;
     this.bookName = bookName;
     this.author = author;
     this.publisher = publisher;
     this.quantity = quantity;
 }

 @Override
 public String toString() {
     return "BookID: " + bookId +
            ", Name: " + bookName +
            ", Author: " + author +
            ", Publisher: " + publisher +
            ", Quantity: " + quantity;
 }
}

public class ArrayListDemo {
 public static void main(String[] args) {

     // 1 & 2) Create an ArrayList using Generics and add Book objects
     ArrayList<Book> bookList = new ArrayList<Book>();

     bookList.add(new Book(101, "Java Basics", "Herbert Schildt", "McGraw-Hill", 5));
     bookList.add(new Book(102, "Data Structures", "Narasimha Karumanchi", "CareerMonk", 3));
     bookList.add(new Book(103, "Operating Systems", "Galvin", "Wiley", 4));
     bookList.add(new Book(104, "Computer Networks", "Tanenbaum", "Pearson", 2));

     // 3) Display size of ArrayList
     System.out.println("Size of ArrayList: " + bookList.size());

     // 4) Display all elements from ArrayList
     System.out.println("\nAll Books in ArrayList (using for-each loop):");
     for (Book b : bookList) {
         System.out.println(b);
     }

     // 5) Remove one element from ArrayList
     // e.g., remove book at index 2 (third book)
     if (!bookList.isEmpty()) {
         System.out.println("\nRemoving one book (index 2)...");
         bookList.remove(2);
     }

     // 6) Display elements after removing
     System.out.println("\nBooks after removing (using Iterator):");
     Iterator<Book> it = bookList.iterator();
     while (it.hasNext()) {
         System.out.println(it.next());
     }

     System.out.println("\nFinal size of ArrayList: " + bookList.size());
 }
}

