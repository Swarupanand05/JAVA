package exp2;

import java.util.Scanner;

import exp2.Matrix;

public class Matrix {
 private int rows;
 private int cols;
 private double[][] data;

 // Constructor with size
 public Matrix(int rows, int cols) {
     this.rows = rows;
     this.cols = cols;
     data = new double[rows][cols];
 }

 // Constructor from 2D array
 public Matrix(double[][] data) {
     this.rows = data.length;
     this.cols = data[0].length;
     this.data = new double[rows][cols];

     for (int i = 0; i < rows; i++) {
         if (data[i].length != cols) {
             throw new IllegalArgumentException("All rows must have same number of columns");
         }
         for (int j = 0; j < cols; j++) {
             this.data[i][j] = data[i][j];
         }
     }
 }

 // Read matrix elements from user
 public void readFromUser(Scanner sc) {
     System.out.println("Enter elements (" + rows + " x " + cols + "):");
     for (int i = 0; i < rows; i++) {
         for (int j = 0; j < cols; j++) {
             data[i][j] = sc.nextDouble();
         }
     }
 }

 // Print matrix
 public void print() {
     for (int i = 0; i < rows; i++) {
         for (int j = 0; j < cols; j++) {
             System.out.print(data[i][j] + "\t");
         }
         System.out.println();
     }
 }

 // Addition
 public Matrix add(Matrix other) {
     if (this.rows != other.rows || this.cols != other.cols) {
         throw new IllegalArgumentException("Addition not possible: dimensions must be same.");
     }

     Matrix result = new Matrix(rows, cols);
     for (int i = 0; i < rows; i++) {
         for (int j = 0; j < cols; j++) {
             result.data[i][j] = this.data[i][j] + other.data[i][j];
         }
     }
     return result;
 }

 // Subtraction
 public Matrix subtract(Matrix other) {
     if (this.rows != other.rows || this.cols != other.cols) {
         throw new IllegalArgumentException("Subtraction not possible: dimensions must be same.");
     }

     Matrix result = new Matrix(rows, cols);
     for (int i = 0; i < rows; i++) {
         for (int j = 0; j < cols; j++) {
             result.data[i][j] = this.data[i][j] - other.data[i][j];
         }
     }
     return result;
 }

 // Matrix multiplication (this * other)
 public Matrix multiply(Matrix other) {
     if (this.cols != other.rows) {
         throw new IllegalArgumentException(
             "Multiplication not possible: cols of first must equal rows of second."
         );
     }

     Matrix result = new Matrix(this.rows, other.cols);

     for (int i = 0; i < this.rows; i++) {
         for (int j = 0; j < other.cols; j++) {
             double sum = 0;
             for (int k = 0; k < this.cols; k++) {
                 sum += this.data[i][k] * other.data[k][j];
             }
             result.data[i][j] = sum;
         }
     }

     return result;
 }

 // Element-wise division (A / B)
 public Matrix divide(Matrix other) {
     if (this.rows != other.rows || this.cols != other.cols) {
         throw new IllegalArgumentException("Division not possible: dimensions must be same.");
     }

     Matrix result = new Matrix(rows, cols);
     for (int i = 0; i < rows; i++) {
         for (int j = 0; j < cols; j++) {
             if (other.data[i][j] == 0) {
                 throw new ArithmeticException("Division by zero at position (" + i + "," + j + ")");
             }
             result.data[i][j] = this.data[i][j] / other.data[i][j];
         }
     }
     return result;
 }

 // Scalar multiplication (k * A)
 public Matrix scalarMultiply(double k) {
     Matrix result = new Matrix(rows, cols);
     for (int i = 0; i < rows; i++) {
         for (int j = 0; j < cols; j++) {
             result.data[i][j] = k * this.data[i][j];
         }
     }
     return result;
 }

 // Transpose of matrix
 public Matrix transpose() {
     Matrix result = new Matrix(cols, rows);
     for (int i = 0; i < rows; i++) {
         for (int j = 0; j < cols; j++) {
             result.data[j][i] = this.data[i][j];
         }
     }
     return result;
 }
}
