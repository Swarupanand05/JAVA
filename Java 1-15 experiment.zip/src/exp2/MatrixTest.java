package exp2;

import java.util.Scanner;

import exp2.Matrix;

public class MatrixTest {
 public static void main(String[] args) {
     Scanner sc = new Scanner(System.in);

     // Take size input for matrices
     System.out.print("Enter number of rows for matrices A and B: ");
     int rows = sc.nextInt();

     System.out.print("Enter number of columns for matrices A and B: ");
     int cols = sc.nextInt();

     // Create two matrices of same size
     Matrix A = new Matrix(rows, cols);
     Matrix B = new Matrix(rows, cols);

     System.out.println("Enter elements of Matrix A:");
     A.readFromUser(sc);

     System.out.println("Enter elements of Matrix B:");
     B.readFromUser(sc);

     System.out.println("Matrix A:");
     A.print();

     System.out.println("Matrix B:");
     B.print();

     // Addition
     try {
         System.out.println("A + B:");
         Matrix addResult = A.add(B);
         addResult.print();
     } catch (IllegalArgumentException e) {
         System.out.println(e.getMessage());
     }

     // Subtraction
     try {
         System.out.println("A - B:");
         Matrix subResult = A.subtract(B);
         subResult.print();
     } catch (IllegalArgumentException e) {
         System.out.println(e.getMessage());
     }

     // Multiplication (A * B) – only if valid
     try {
         System.out.println("A * B:");
         Matrix mulResult = A.multiply(B);
         mulResult.print();
     } catch (IllegalArgumentException e) {
         System.out.println(e.getMessage());
     }

     // Element-wise division (A / B)
     try {
         System.out.println("A / B (element-wise):");
         Matrix divResult = A.divide(B);
         divResult.print();
     } catch (IllegalArgumentException | ArithmeticException e) {
         System.out.println(e.getMessage());
     }

     // Scalar multiplication
     System.out.print("Enter scalar value to multiply with Matrix A: ");
     double k = sc.nextDouble();
     System.out.println("k * A:");
     Matrix scalarResult = A.scalarMultiply(k);
     scalarResult.print();

     // Transpose of A
     System.out.println("Transpose of A:");
     Matrix tA = A.transpose();
     tA.print();

     sc.close();
 }
}

