package exp3;

public class EmployeeTest {
	 public static void main(String[] args) {

	     // Creating 2 employees
	     Employee emp1 = new Employee("Swarup", "Patil", 25000);
	     Employee emp2 = new Employee("Akash", "Desai", 30000);

	     System.out.println("----- Yearly Salary Before Raise -----");
	     System.out.println(emp1.getFirstName() + " " + emp1.getLastName() +
	             ": Rs. " + emp1.getYearlySalary());

	     System.out.println(emp2.getFirstName() + " " + emp2.getLastName() +
	             ": Rs. " + emp2.getYearlySalary());

	     // Give 10% raise
	     emp1.giveRaise();
	     emp2.giveRaise();

	     System.out.println("\n----- Yearly Salary After 10% Raise -----");
	     System.out.println(emp1.getFirstName() + " " + emp1.getLastName() +
	             ": Rs. " + emp1.getYearlySalary());

	     System.out.println(emp2.getFirstName() + " " + emp2.getLastName() +
	             ": Rs. " + emp2.getYearlySalary());
	 }
	}
