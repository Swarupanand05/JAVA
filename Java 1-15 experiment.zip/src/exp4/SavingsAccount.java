package exp4;

public class SavingsAccount {

	 private static double annualInterestRate;  // static variable shared by all savers
	 private double savingsBalance;             // instance variable (unique for each object)

	 // Parameterized constructor
	 public SavingsAccount(double balance) {
	     this.savingsBalance = balance;
	 }

	 // Method to calculate monthly interest
	 public void calculateMonthlyInterest() {
	     double monthlyInterest = (savingsBalance * annualInterestRate) / 12;
	     savingsBalance += monthlyInterest;  // add interest to current balance
	 }

	 // Static method to set new interest rate
	 public static void modifyInterestRate(double newRate) {
	     annualInterestRate = newRate;
	 }

	 // Getter for balance
	 public double getSavingsBalance() {
	     return savingsBalance;
	 }
	}