package exp4;


public class SavingsAccountTest {
	 public static void main(String[] args) {

	     // Create two account objects
	     SavingsAccount saver1 = new SavingsAccount(2000.00);
	     SavingsAccount saver2 = new SavingsAccount(3000.00);

	     // Set annual interest rate to 4% (0.04)
	     SavingsAccount.modifyInterestRate(0.04);

	     // Calculate monthly interest
	     saver1.calculateMonthlyInterest();
	     saver2.calculateMonthlyInterest();

	     System.out.println("---- After applying 4% annual interest ----");
	     System.out.println("Saver1 Balance: Rs " + saver1.getSavingsBalance());
	     System.out.println("Saver2 Balance: Rs " + saver2.getSavingsBalance());

	     // Now set annual interest rate to 5% (0.05)
	     SavingsAccount.modifyInterestRate(0.05);

	     // Calculate interest for next month
	     saver1.calculateMonthlyInterest();
	     saver2.calculateMonthlyInterest();

	     System.out.println("\n---- After applying 5% annual interest ----");
	     System.out.println("Saver1 Balance: Rs " + saver1.getSavingsBalance());
	     System.out.println("Saver2 Balance: Rs " + saver2.getSavingsBalance());
	 }
	}

