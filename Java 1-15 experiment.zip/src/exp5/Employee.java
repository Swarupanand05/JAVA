package exp5;

public class Employee extends Person {

 int empId;
 double salary;

 public Employee(String name, int birthYear, double height, double weight, String address,
                 int empId, double salary) {

     super(name, birthYear, height, weight, address);
     this.empId = empId;
     this.salary = salary;
 }

 public double calculateTax() {
     return salary * 0.10; // 10% tax
 }

 public void displayEmployeeInfo() {
     System.out.println("----- Employee Details -----");
     displayPersonInfo();
     System.out.println("Emp ID    : " + empId);
     System.out.println("Salary    : " + salary);
     System.out.println("Tax (10%) : " + calculateTax());
     System.out.println();
 }
}

