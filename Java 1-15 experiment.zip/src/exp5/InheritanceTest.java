package exp5;

//InheritanceTest.java
public class InheritanceTest {
 public static void main(String[] args) {

     // Student object
     double[] studMarks = {85.5, 90.0, 78.0};
     Student s1 = new Student(
             "Swarup",
             2005,
             170.0,
             65.0,
             "Ichalkaranji",
             23,
             studMarks
     );

     // Employee object
     Employee e1 = new Employee(
             "Akash",
             1998,
             175.0,
             72.0,
             "Kolhapur",
             101,
             45000.0
     );

     // Show details
     s1.displayStudentInfo();
     e1.displayEmployeeInfo();
 }
}

