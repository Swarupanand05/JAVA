package exp5;

//Person.java
import java.time.LocalDate;

public class Person {
 String name;
 int birthYear;
 double height;
 double weight;
 String address;

 public Person(String name, int birthYear, double height, double weight, String address) {
     this.name = name;
     this.birthYear = birthYear;
     this.height = height;
     this.weight = weight;
     this.address = address;
 }

 public int calculateAge() {
     int currentYear = LocalDate.now().getYear();
     return currentYear - birthYear;
 }

 public void displayPersonInfo() {
     System.out.println("Name      : " + name);
     System.out.println("BirthYear : " + birthYear + " (Age: " + calculateAge() + ")");
     System.out.println("Height    : " + height + " cm");
     System.out.println("Weight    : " + weight + " kg");
     System.out.println("Address   : " + address);
 }
}

