package exp5;

//Student.java
public class Student extends Person {

 int rollNo;
 double[] marks;

 public Student(String name, int birthYear, double height, double weight, String address,
                int rollNo, double[] marks) {

     super(name, birthYear, height, weight, address);
     this.rollNo = rollNo;
     this.marks = marks;
 }

 public double calculateAvg() {
     double sum = 0;
     for (double m : marks) {
         sum += m;
     }
     return sum / marks.length;
 }

 public void displayStudentInfo() {
     System.out.println("----- Student Details -----");
     displayPersonInfo();
     System.out.println("Roll No   : " + rollNo);
     System.out.print("Marks     : ");
     for (double m : marks) {
         System.out.print(m + " ");
     }
     System.out.println();
     System.out.println("Average   : " + calculateAvg());
     System.out.println();
 }
}

