package exp6;

//QueueInterface.java
public interface QueueInterface {
 void enqueue(int element);
 int dequeue();
 void display();    // same name as in StackInterface (multiple inheritance)
}

