package exp6;

//StackInterface.java
public interface StackInterface {
 void push(int element);
 int pop();
 int peek();
 void display();    // will display stack and queue (since both interfaces use this)
}

