package exp6;

//StackQueue.java
public class StackQueue implements StackInterface, QueueInterface {

 private int[] stack;
 private int top;

 private int[] queue;
 private int front;
 private int rear;
 private int count;

 private int maxSize;

 public StackQueue(int size) {
     maxSize = size;
     stack = new int[maxSize];
     queue = new int[maxSize];
     top = -1;
     front = 0;
     rear = -1;
     count = 0;
 }

 // ---------------- Stack Methods ----------------

 @Override
 public void push(int element) {
     if (top == maxSize - 1) {
         System.out.println("Stack Overflow!");
     } else {
         stack[++top] = element;
         System.out.println(element + " pushed to stack.");
     }
 }

 @Override
 public int pop() {
     if (top == -1) {
         System.out.println("Stack Underflow!");
         return -1;
     } else {
         int val = stack[top--];
         System.out.println(val + " popped from stack.");
         return val;
     }
 }

 @Override
 public int peek() {
     if (top == -1) {
         System.out.println("Stack is empty!");
         return -1;
     } else {
         return stack[top];
     }
 }

 // ---------------- Queue Methods ----------------

 @Override
 public void enqueue(int element) {
     if (count == maxSize) {
         System.out.println("Queue Overflow!");
     } else {
         rear = (rear + 1) % maxSize;
         queue[rear] = element;
         count++;
         System.out.println(element + " enqueued to queue.");
     }
 }

 @Override
 public int dequeue() {
     if (count == 0) {
         System.out.println("Queue Underflow!");
         return -1;
     } else {
         int val = queue[front];
         front = (front + 1) % maxSize;
         count--;
         System.out.println(val + " dequeued from queue.");
         return val;
     }
 }

 // ---------------- Common Display (for both interfaces) ----------------

 @Override
 public void display() {
     System.out.println("------ Stack Elements (top to bottom) ------");
     if (top == -1) {
         System.out.println("Stack is empty.");
     } else {
         for (int i = top; i >= 0; i--) {
             System.out.println(stack[i]);
         }
     }

     System.out.println("------ Queue Elements (front to rear) ------");
     if (count == 0) {
         System.out.println("Queue is empty.");
     } else {
         int temp = front;
         for (int i = 0; i < count; i++) {
             System.out.println(queue[temp]);
             temp = (temp + 1) % maxSize;
         }
     }
     System.out.println("-------------------------------------------");
 }
}
