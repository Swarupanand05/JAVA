package exp6;

//StackQueueTest.java
import java.util.Scanner;

public class StackQueueTest {
 public static void main(String[] args) {
     Scanner sc = new Scanner(System.in);

     System.out.print("Enter size of Stack and Queue: ");
     int size = sc.nextInt();

     StackQueue sq = new StackQueue(size);

     int choice;
     do {
         System.out.println("\n------ Menu ------");
         System.out.println("1. Push (Stack)");
         System.out.println("2. Pop (Stack)");
         System.out.println("3. Peek (Stack)");
         System.out.println("4. Enqueue (Queue)");
         System.out.println("5. Dequeue (Queue)");
         System.out.println("6. Display Stack and Queue");
         System.out.println("7. Exit");
         System.out.print("Enter your choice: ");
         choice = sc.nextInt();

         switch (choice) {
             case 1:
                 System.out.print("Enter element to push: ");
                 int x = sc.nextInt();
                 sq.push(x);
                 break;

             case 2:
                 sq.pop();
                 break;

             case 3:
                 int top = sq.peek();
                 if (top != -1) {
                     System.out.println("Top element: " + top);
                 }
                 break;

             case 4:
                 System.out.print("Enter element to enqueue: ");
                 int y = sc.nextInt();
                 sq.enqueue(y);
                 break;

             case 5:
                 sq.dequeue();
                 break;

             case 6:
                 sq.display();
                 break;

             case 7:
                 System.out.println("Exiting...");
                 break;

             default:
                 System.out.println("Invalid choice!");
         }
     } while (choice != 7);

     sc.close();
 }
}

