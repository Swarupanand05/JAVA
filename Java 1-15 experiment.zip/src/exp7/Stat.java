// File: Stat.java
package exp7;

public class Stat {

    // minimum value
    public float min(float[] data) {
        if (data == null || data.length == 0) {
            System.out.println("Empty array!");
            return Float.NaN;
        }
        float min = data[0];
        for (int i = 1; i < data.length; i++) {
            if (data[i] < min) {
                min = data[i];
            }
        }
        return min;
    }

    // maximum value
    public float max(float[] data) {
        if (data == null || data.length == 0) {
            System.out.println("Empty array!");
            return Float.NaN;
        }
        float max = data[0];
        for (int i = 1; i < data.length; i++) {
            if (data[i] > max) {
                max = data[i];
            }
        }
        return max;
    }

    // count of elements
    public int count(float[] data) {
        if (data == null) return 0;
        return data.length;
    }

    // sum of all values
    public float sum(float[] data) {
        if (data == null || data.length == 0) {
            return 0;
        }
        float s = 0;
        for (float v : data) {
            s += v;
        }
        return s;
    }

    // average of values
    public float average(float[] data) {
        int c = count(data);
        if (c == 0) {
            System.out.println("Cannot compute average of empty array!");
            return Float.NaN;
        }
        return sum(data) / c;
    }
}
