// File: Trig.java
package exp7;

public class Trig {

    private double angleDegrees;

    // constructor
    public Trig(double angleDegrees) {
        this.angleDegrees = angleDegrees;
    }

    // optional setter
    public void setAngleDegrees(double angleDegrees) {
        this.angleDegrees = angleDegrees;
    }

    // convert to radians for Math library
    private double toRadians() {
        return Math.toRadians(angleDegrees);
    }

    public double getSine() {
        return Math.sin(toRadians());
    }

    public double getCosine() {
        return Math.cos(toRadians());
    }

    public double getTangent() {
        return Math.tan(toRadians());
    }

    public double getSecant() {
        double cos = getCosine();
        if (cos == 0) {
            System.out.println("Secant is undefined for this angle.");
            return Double.NaN;
        }
        return 1.0 / cos;
    }

    public double getCosecant() {
        double sin = getSine();
        if (sin == 0) {
            System.out.println("Cosecant is undefined for this angle.");
            return Double.NaN;
        }
        return 1.0 / sin;
    }

    public double getCotangent() {
        double tan = getTangent();
        if (tan == 0) {
            System.out.println("Cotangent is undefined for this angle.");
            return Double.NaN;
        }
        return 1.0 / tan;
    }
}
