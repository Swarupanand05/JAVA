package fileHandling;

//ReadFile.java
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReadFile {

 public static void main(String[] args) {

     BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
     String fileName = null;

     try {
         // Step 2: Get name of the file from user
         System.out.print("Enter file name (with path if needed): ");
         fileName = br.readLine();

         // Step 3: Read and display contents of file using FileInputStream
         readFileContents(fileName);

         // Step 4: Ask user if they want to add contents to the file
         System.out.print("\nDo you want to append data to this file? (y/n): ");
         String choice = br.readLine();

         if (choice.equalsIgnoreCase("y")) {
             // Step 5: Read the contents from the user
             System.out.println("Enter text to append (single line).");
             System.out.println("Note: This text will be written at the end of the file.");
             System.out.print(">> ");
             String data = br.readLine();

             // Step 6 & 7: Create FileOutputStream in append mode and write data
             appendToFile(fileName, data);

             System.out.println("\nData appended successfully. Updated file contents:\n");
             readFileContents(fileName);
         } else {
             System.out.println("No changes made to the file.");
         }

     } catch (IOException e) {
         System.out.println("An I/O error occurred: " + e.getMessage());
     } finally {
         try {
             if (br != null) {
                 br.close();
             }
         } catch (IOException e) {
             System.out.println("Error closing BufferedReader: " + e.getMessage());
         }
     }
 }

 // Method to read and display file contents
 private static void readFileContents(String fileName) {
     FileInputStream fis = null;
     try {
         fis = new FileInputStream(fileName);
         System.out.println("\n----- File Contents -----");

         int ch;
         while ((ch = fis.read()) != -1) {
             System.out.print((char) ch);
         }

         System.out.println("\n-------------------------");

     } catch (FileNotFoundException e) {
         System.out.println("\nFile not found. It will be created if you choose to append data.");
     } catch (IOException e) {
         System.out.println("Error reading file: " + e.getMessage());
     } finally {
         if (fis != null) {
             try {
                 fis.close();
             } catch (IOException e) {
                 System.out.println("Error closing file: " + e.getMessage());
             }
         }
     }
 }

 // Method to append text to file (creates file if it does not exist)
 private static void appendToFile(String fileName, String data) {
     FileOutputStream fos = null;
     try {
         // true → append mode; also creates file if it does not exist
         fos = new FileOutputStream(fileName, true);
         // add newline before appending (optional)
         String toWrite = data + System.lineSeparator();
         fos.write(toWrite.getBytes());
     } catch (IOException e) {
         System.out.println("Error writing to file: " + e.getMessage());
     } finally {
         if (fos != null) {
             try {
                 fos.close();
             } catch (IOException e) {
                 System.out.println("Error closing file output stream: " + e.getMessage());
             }
         }
     }
 }
}

